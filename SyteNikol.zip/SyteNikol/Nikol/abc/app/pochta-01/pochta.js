﻿function checkForm1(){
	var	obj = document.getElementById('ftab');
    // объявляем переменную куда будет заносится текст сообщения
    var error_msg = "";

/* все для поля Телефон */
	// регулярное выражение, для проверки
	var reg_ph = /^(\+|\S)?[0-9]{12};
    // заносим значение поля Телефон в переменную ph
    var ph = obj.phone.value;
	//проверка поля Телефон
    if(reg_ph.exec(ph) == null){
    error_msg += "Не корректно заполнено поле телефон! ";
    } else {
	error_msg.replace ("Не корректно заполнено поле телефон! ","");
	}
/*-------------------*/
/* все для поля email */
	// регулярное выражение, для проверки 
    var reg_mail = /[0-9a-z_.]+@[0-9a-z_^.]+.[a-z]{2,3}/i;
    // заносим значение поля в переменную mail
    var mail = obj.email.value;
    //проверка поля 
    if(reg_mail.exec(mail) == null){
    error_msg += "<br />Не корректно заполнено поле email! ";
    } else {
    error_msg.replace ("Не корректно заполнено поле email! ","");
	}
/*-------------------*/

	document.getElementById('er').innerHTML=error_msg;
}


function checkForm(){
	var error_msg = document.getElementById('er').innerHTML;
	var	obj = document.getElementById('ftab');
	if (error_msg == "")
	return true;
	else
	return false;

	}

