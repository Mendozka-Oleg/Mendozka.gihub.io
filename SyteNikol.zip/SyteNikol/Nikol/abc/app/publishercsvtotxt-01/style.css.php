.dn {display:none;}
.co-pr {margin-left:25px;}
.co-pr form {display:inline-block;margin:10px 20px 10px 0;}
.co-pr form input[type="submit"]{height:36px;width:210px;color:#555555;background:#dddddd;font-size:12px;text-transform:uppercase;border-radius:5px;}
.co-pr form input[type="submit"]:hover {color:#ffffff;background:#3C3F3E;}
.pseudoinput{display:inline-block;position:relative;color:#555555;background:#dddddd;text-transform:uppercase;vertical-align:top;overflow:hidden;margin-right:10px;border-radius:5px;}
.pseudoinput span{display:inline-block;width:70px;padding:11px 10px;font-size:12px;text-align:center;}
.pseudoinput:hover{color:#ffffff;background:#3C3F3E;}
.co-pr input[type="file"]{position:absolute;top:0;left:0;height:40px;width:90px;opacity:0;}
.ctrl {margin-top: 30px; margin-left: 280px;}
.co-pr::after {display:block;clear:both;content:'';}
.q {display:block;float:none;color:#555555;background:#f8f8f8;font-size:12px;font-style:italic;margin:0 30px 0 50px;padding:10px;}

.aa-002 /*admin*/ {display:block;float:none;color:#444444;background:#dddddd;text-transform:uppercase;margin-right:50px;padding:10px;}
.aa-002 /*admin*/ {display:block;float:none;color:#444444;background:#dddddd;text-transform:uppercase;margin-right:50px;padding:10px;}
/* border-radius структурных боков*/
.aa-002 {-o-border-radius:5px;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px;}
.aa-002:hover {color:#ffffff;background:#3C3F3E;}
.disable {color:#777777;background:#eeeeee;}
/*
.co-pr a.publ:link{{display:block;height: 40px;width: 210px;border:1px solid #000;border-radius:5px;}
.co-pr a.publ:visited {{display:none;background:#000000;}
.co-pr a.publ:active {background:#ffff00;}
.co-pr a.publ:hover {background:#ff0000;}
*/