﻿#LG_container{position:absolute;visibility:hidden;top:0px;left:0px;background-color:#444;background-position:center;background-repeat:no-repeat;font:normal 12px verdana, arial, sans-serif;opacity:1;padding:2px;margin:0 0 0 -20px;border:1px solid #aaa;z-index:1000004;}
#LG_loading {display:none;position:absolute;top:50%;left:50%;width:40px;height:40px;background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/ico-loading.gif) center;margin:-20px 0 0 -20px;}

#LG_prevLink,#LG_nextLink{cursor:pointer;position:absolute;top:36px;opacity:0;filter:alpha(opacity=0);}
#LG_prevLink{left:0;background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/prev.png) left 80px;}
#LG_nextLink{right:0;background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/next.png) right 80px;}

#LG_imgIndex{float:left;height:32px;color:#eee;line-height:32px;margin-left:16px;}
#LG_titleBar{height:30px;color:#ddd;text-align:center;line-height:36px;overflow:hidden;}
#LG_overlay{display:none;position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;filter:Alpha(opacity=0);z-index:1000003;}
#LG_pic{display:none;margin:0 auto}

#LG_zoomIn, #LG_zoomOut, #LG_zoomNormal, #LG_fitScreen, #LG_zoom_disabled{display:block;float:left;width:32px;height:32px;margin:1px;cursor:pointer;}
#LG_zoom_disabled {display:none;}
#LG_zoomIn{background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/sprite.png) -16px -16px}
#LG_zoomNormal{background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/sprite.png) -16px -272px}
#LG_zoomOut{background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/sprite.png) -16px -80px}
#LG_fitScreen{background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/sprite.png) -16px -208px}
#LG_closeBtn{float:right;width:32px;height:32px;background:no-repeat url(/tms/lib/scr/lightgallery/skins/snow/sprite.png) -16px -144px;cursor:pointer;}
